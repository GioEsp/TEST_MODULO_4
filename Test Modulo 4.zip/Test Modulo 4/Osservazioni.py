"""
    Dai dati che abbiamo ottenuto dall'analisi del file CSV preso in 
    considerazione, prendendo in esame i tre continenti Europe, South America e
    Oceania abbiamo tratto in conclusione quanto segue:
    - per quanto riguarda i casi covid il più colpito è
    stato il continente europeo seguito da Sud America e Oceania.
    - per quanto riguarda le vaccinazioni, in correlazione ai contagi, i 
    continenti per numero di vaccinazioni (sul totale mondiale) sono in 
    ordine quantitativo Europa, Sud America e Oceania.
"""