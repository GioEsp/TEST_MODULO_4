import pandas as pd

def casi_continente(dataset):
    # Carica il dataset
    df = pd.read_csv(dataset)

    # Filtra il dataset per le locazioni che appartengono ad un continente valido
    df = df[df['continent'].notnull()]
    
    # Filtra i valori del dataset che appartengono ad un continente
    df = df.dropna(subset=['continent'])

    # Richiede all'utente di inserire i nomi dei continenti da analizzare
    print()
    continenti = []
    while True:
        continente = input("Inserisci il nome del continente (premi invio per terminare): ")
        if continente == '':
            break
        if continente not in df['continent'].unique():
            print("Il nome del continente non esiste nel dataset. Per favore, riscrivilo.")
            continue
        continenti.append(continente)

    # Crea una lista per i risultati
    risultati = []

    # Calcola le statistiche per ogni continente
    for continente in continenti:
        df_continente = df[df['continent'] == continente]
        casi_totali = df_continente['total_cases']
        minimo = casi_totali.min()
        massimo = casi_totali.max()
        media = casi_totali.mean()
        percentuale = casi_totali.sum() / df['total_cases'].sum() * 100

        # Aggiunge i risultati alla lista
        risultati.append({
            'Continente': continente,
            'Minimo': minimo,
            'Massimo': massimo,
            'Media': media,
            '%/Tot Mondo': percentuale
        })

    # Crea un DataFrame dai risultati
    df_risultati = pd.DataFrame(risultati)

    # Visualizza il DataFrame dei risultati
    print()
    print("Casi covid:")
    print()
    print(df_risultati)
    print()

# Utilizzo ('percorso_tuo_file.csv')
dataset = (r'C:\Users\giova\Desktop\owid-covid-data.csv')
casi_continente(dataset)