import pandas as pd

# Carica il file CSV
df = pd.read_csv(r'C:\Users\giova\Desktop\owid-covid-data.csv')

'''
  oppure:  with open('percorso_del_file.csv', mode='r') as file_csv
'''

# Calcola il numero totale di casi per continente
casi_per_continente = df.groupby('continent')['total_cases'].sum()

# Rinomina l'intestazione della colonna
casi_per_continente = casi_per_continente.rename_axis('Continente:')

# Stampa i risultati
print()
print("Numero totale di casi per continente:")
print()
print(casi_per_continente.to_string())
print()