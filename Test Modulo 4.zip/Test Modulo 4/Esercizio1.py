import pandas as pd

# Carica il file CSV
df = pd.read_csv(r'C:\Users\giova\Desktop\owid-covid-data.csv')

'''
    Oppure caricare il file CSV con: 
    with open('percorso_tuo_file.csv', mode='r') as file_csv
'''

# Verifica le dimensioni del dataset
num_righe, num_colonne = df.shape
print(f"Numero di righe: {num_righe}")
print(f"Numero di colonne: {num_colonne}")

# Verifica le diciture dell'intestazione
intestazione = df.columns.tolist()
print()
print("Intestazione:")
print()
print(intestazione)
print()