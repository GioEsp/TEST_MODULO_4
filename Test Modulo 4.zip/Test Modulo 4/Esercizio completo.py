# RICHIESTA 1
import pandas as pd

# Carica il file CSV
df = pd.read_csv(r'C:\Users\giova\Desktop\owid-covid-data.csv')

'''
    Oppure caricare il file CSV con: 
    with open('percorso_tuo_file.csv', mode='r') as file_csv
'''

# Verifica le dimensioni del dataset
num_righe, num_colonne = df.shape
print(f"Numero di righe: {num_righe}")
print(f"Numero di colonne: {num_colonne}")

# Verifica le diciture dell'intestazione
intestazione = df.columns.tolist()
print()
print("Intestazione:")
print()
print(intestazione)
print()


#RICHIESTA 2
import pandas as pd

# Carica il file CSV
df = pd.read_csv(r'C:\Users\giova\Desktop\owid-covid-data.csv')

'''
  oppure:  with open('percorso_del_file.csv', mode='r') as file_csv
'''

# Calcola il numero totale di casi per continente
casi_per_continente = df.groupby('continent')['total_cases'].sum()

# Rinomina l'intestazione della colonna
casi_per_continente = casi_per_continente.rename_axis('Continente:')

# Stampa i risultati
print()
print("Numero totale di casi per continente:")
print()
print(casi_per_continente.to_string())
print()


# RICHIESTA 3
import pandas as pd

def casi_continente(dataset):
    # Carica il dataset
    df = pd.read_csv(dataset)

    # Filtra il dataset per le locazioni che appartengono ad un continente valido
    df = df[df['continent'].notnull()]
    
    # Filtra i valori del dataset che appartengono ad un continente
    df = df.dropna(subset=['continent'])

    # Richiede all'utente di inserire i nomi dei continenti da analizzare
    print()
    continenti = []
    while True:
        continente = input("Inserisci il nome del continente (premi invio per terminare): ")
        if continente == '':
            break
        if continente not in df['continent'].unique():
            print("Il nome del continente non esiste nel dataset. Per favore, riscrivilo.")
            continue
        continenti.append(continente)

    # Crea una lista per i risultati
    risultati = []

    # Calcola le statistiche per ogni continente
    for continente in continenti:
        df_continente = df[df['continent'] == continente]
        casi_totali = df_continente['total_cases']
        minimo = casi_totali.min()
        massimo = casi_totali.max()
        media = casi_totali.mean()
        percentuale = casi_totali.sum() / df['total_cases'].sum() * 100

        # Aggiunge i risultati alla lista
        risultati.append({
            'Continente': continente,
            'Minimo': minimo,
            'Massimo': massimo,
            'Media': media,
            '%/Tot Mondo': percentuale
        })

    # Crea un DataFrame dai risultati
    df_risultati = pd.DataFrame(risultati)

    # Visualizza il DataFrame dei risultati
    print()
    print("Casi covid:")
    print()
    print(df_risultati)
    print()

# Utilizzo ('percorso_tuo_file.csv')
dataset = (r'C:\Users\giova\Desktop\owid-covid-data.csv')
casi_continente(dataset)


#RICHIESTA 4
import pandas as pd

def vaccinazioni_continente(dataset):
    # Carica il dataset
    df = pd.read_csv(dataset)
   
    # Filtra il dataset per le locazioni che appartengono a un continente valido
    df = df[df['continent'].notnull()]
    
    # Filtra i valori del dataset che appartengono ad un continente valido
    df = df.dropna(subset=['continent'])

    # Richiede all'utente di inserire i nomi dei continenti da analizzare
    print()
    continenti = []
    while True:
        continente = input("Inserisci il nome del continente (premi invio per terminare): ")
        if continente == '':
            break
        if continente not in df['continent'].unique():
            print("Il nome del continente non esiste nel dataset. Per favore, riscrivilo.")
            continue
        continenti.append(continente)

    # Crea una lista per i risultati
    risultati = []

    # Calcola le statistiche per ogni continente
    for continente in continenti:
        df_continente = df[df['continent'] == continente]
        vaccinazioni_totali = df_continente['total_vaccinations']
        minimo = vaccinazioni_totali.min()
        massimo = vaccinazioni_totali.max()
        media = vaccinazioni_totali.mean()
        percentuale = vaccinazioni_totali.sum() / df['total_vaccinations'].sum() * 100

        # Aggiunge i risultati alla lista
        risultati.append({
            'Continente': continente,
            'Minimo': minimo,
            'Massimo': massimo,
            'Media': media,
            'Percentuale': percentuale
        })

    # Crea un DataFrame dai risultati
    df_risultati = pd.DataFrame(risultati)

    # Visualizza il DataFrame dei risultati
    print()
    print("Vaccinazioni:")
    print()
    print(df_risultati)
    print()

# Utilizo ('percorso_tuo_file.csv')
dataset = (r'C:\Users\giova\Desktop\owid-covid-data.csv')
vaccinazioni_continente(dataset)


#RICHIESTA 5
"""
Dai dati emersi dall'analisi del file CSV preso in 
considerazione, prendendo in esame i tre continenti Europe, South America e
Oceania abbiamo tratto in conclusione quanto segue:
- per quanto riguarda i casi covid il più colpito è
stato il continente europeo seguito da Sud America e Oceania.
- per quanto riguarda le vaccinazioni, in correlazione ai contagi, i 
continenti per numero di vaccinazioni (sul totale mondiale) sono in 
ordine quantitativo Europa, Sud America e Oceania.
"""